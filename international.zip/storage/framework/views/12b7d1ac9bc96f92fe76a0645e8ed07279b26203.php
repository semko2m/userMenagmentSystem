<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Users</div>
                    <div class="panel-body">
                        <?php if(isset($user->id)): ?>
                            <?php echo Form::open(['route'=>['admin.updateUserDb',$user->id],'class'=>'form-horizontal','method'=>'put']); ?>

                        <?php else: ?>
                            <?php echo Form::open(['route'=>['admin.createUser', $type],'class'=>'form-horizontal','method'=>'put']); ?>

                        <?php endif; ?>

                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-3 control-label">Name</label>

                            <div class="col-md-6">
                                <?php echo Form::text('name', isset($user->name)? $user->name:'', ['id'=>'name','class' => 'form-control required']); ?>


                                <?php if($errors->has('name')): ?>
                                    <span class="help-block"><strong><?php echo e($errors->first('name')); ?></strong></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="key" class="col-md-3 control-label">Email</label>

                            <div class="col-md-6">
                                <?php echo Form::email('email', isset($user->email)? $user->email:'', ['id'=>'email','class' => 'form-control required']); ?>


                                <?php if($errors->has('email')): ?>
                                    <span class="help-block"><strong><?php echo e($errors->first('email')); ?></strong></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-3 control-label">Password</label>

                            <div class="col-md-6">

                                <?php echo Form::password('password', ['id'=>'password','class' => 'form-control required']); ?>



                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-3 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <?php echo Form::password('password_confirmation', ['id'=>'password_confirmation','class' => 'form-control required']); ?>


                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-3">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-users"></i> Register
                                </button>
                            </div>
                        </div>

                        <?php echo Form::close(); ?>


                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Groups</div>
                    <div class="panel-body">
                        <?php if(isset($group->id)): ?>
                            <?php echo Form::open(['route'=>['admin.updateUserDb',$group->id],'class'=>'form-horizontal','method'=>'put']); ?>

                        <?php else: ?>
                            <?php echo Form::open(['route'=>['admin.createGroup'],'class'=>'form-horizontal','method'=>'put']); ?>

                        <?php endif; ?>

                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-3 control-label">Name</label>

                            <div class="col-md-6">
                                <?php echo Form::text('name', isset($group->name)? $group->name:'', ['id'=>'name','class' => 'form-control required']); ?>


                                <?php if($errors->has('name')): ?>
                                    <span class="help-block"><strong><?php echo e($errors->first('name')); ?></strong></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <label for="key" class="col-md-3 control-label">Description</label>

                            <div class="col-md-6">
                                <?php echo Form::text('description', isset($group->description)? $group->description:'', ['id'=>'description','class' => 'form-control required']); ?>


                                <?php if($errors->has('description')): ?>
                                    <span class="help-block"><strong><?php echo e($errors->first('email')); ?></strong></span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-3">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-users"></i> Create
                                </button>
                            </div>
                        </div>

                        <?php echo Form::close(); ?>


                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
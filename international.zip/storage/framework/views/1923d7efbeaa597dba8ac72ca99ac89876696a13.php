<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <p class="col-md-3">
                                All users

                            </p>
                            <div class="col-md-9">
                                <a class="btn btn-default pull-right"
                                   href="<?php echo e(route('admin.create','admin')); ?>">Create new Admin </a>

                                <a class="btn btn-default pull-right"
                                   href="<?php echo e(route('admin.create','user')); ?>">Create new User </a>
                            </div>

                        </div>


                    </div>
                    <div class="panel-body">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Type</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        <?php if($user->hasRole('admin')): ?>
                                            <strong>Admin</strong>
                                        <?php elseif($user->hasRole('user')): ?>
                                            User
                                        <?php endif; ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.deleteUser',$user->id)); ?>">
                                            <i class="fa fa-trash"
                                               aria-hidden="true"
                                               data-toggle="tooltip"
                                               title="Delete User !"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.updateUser',$user->id)); ?>">
                                            <i class="fa fa-pencil"
                                               aria-hidden="true"
                                               data-toggle="tooltip"
                                               title="Update User !"></i>
                                        </a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>